# Backend Code Style

- Use four spaces for indentation and UTF-8 source files.
- Use `UpperCamelCase` for classes and `lowerCamelCase` for methods and fields.
- Keep HTTP concerns in controllers, business rules in services, and expression parsing in the utility parser.
- Use constructor injection and immutable request/response records.
- Validate external input and return explicit HTTP errors.
- Add focused JUnit tests when changing expression parsing or calculation behavior.
